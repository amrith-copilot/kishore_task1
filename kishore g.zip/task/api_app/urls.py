from django.urls import path
from . import views

urlpatterns = [
    # Task endpoints
    path('api/tasks/', views.task_list, name='task-list'),
    path('api/tasks/<int:task_id>/', views.task_detail, name='task-detail'),
    path('api/tasks/status/', views.tasks_by_status, name='tasks-by-status'),
    path('api/tasks/priority/', views.tasks_by_priority, name='tasks-by-priority'),
    
    # User endpoints
    path('api/users/', views.user_list, name='user-list'),
]