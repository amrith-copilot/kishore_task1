from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Task

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']

class TaskSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    user_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = Task
        fields = [
            'id', 
            'user', 
            'user_id',
            'title', 
            'description', 
            'status', 
            'priority', 
            'created', 
            'updated_at'
        ]
        read_only_fields = ['created', 'updated_at']
    
    def validate_user_id(self, value):
        """Validate that the user exists"""
        try:
            User.objects.get(id=value)
        except User.DoesNotExist:
            raise serializers.ValidationError("User with this ID does not exist.")
        return value

class TaskCreateSerializer(serializers.ModelSerializer):
    """Simplified serializer for creating tasks"""
    class Meta:
        model = Task
        fields = ['title', 'description', 'status', 'priority', 'user_id']
        
    user_id = serializers.IntegerField()
    
    def validate_user_id(self, value):
        """Validate that the user exists"""
        try:
            User.objects.get(id=value)
        except User.DoesNotExist:
            raise serializers.ValidationError("User with this ID does not exist.")
        return value
    
    def create(self, validated_data):
        user_id = validated_data.pop('user_id')
        user = User.objects.get(id=user_id)
        validated_data['user'] = user
        return Task.objects.create(**validated_data)