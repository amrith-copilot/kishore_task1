from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.contrib.auth.models import User
import json
from .models import Task

# Create your views here.

@csrf_exempt
@require_http_methods(["GET", "POST"])
def task_list(request):
    """
    GET /api/tasks/ - List all tasks
    POST /api/tasks/ - Create a new task
    """
    if request.method == 'GET':
        tasks = Task.objects.all().values(
            'id', 'title', 'description', 'status', 'priority', 
            'created', 'updated_at', 'user__username', 'user_id'
        )
        return JsonResponse({
            'status': 'success',
            'count': len(tasks),
            'data': list(tasks)
        })
    
    elif request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Validate required fields
            required_fields = ['title', 'description', 'user_id']
            for field in required_fields:
                if field not in data:
                    return JsonResponse({
                        'status': 'error',
                        'message': f'Missing required field: {field}'
                    }, status=400)
            
            # Validate user exists
            try:
                user = User.objects.get(id=data['user_id'])
            except User.DoesNotExist:
                return JsonResponse({
                    'status': 'error',
                    'message': 'User with this ID does not exist'
                }, status=400)
            
            # Create task
            task = Task.objects.create(
                title=data['title'],
                description=data['description'],
                status=data.get('status', 'pending'),
                priority=data.get('priority', 'pending'),
                user=user
            )
            
            return JsonResponse({
                'status': 'success',
                'message': 'Task created successfully',
                'data': {
                    'id': task.id,
                    'title': task.title,
                    'description': task.description,
                    'status': task.status,
                    'priority': task.priority,
                    'created': task.created,
                    'updated_at': task.updated_at,
                    'user_id': task.user_id,
                    'username': task.user.username
                }
            }, status=201)
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON data'
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)

@csrf_exempt
@require_http_methods(["GET", "PUT", "PATCH", "DELETE"])
def task_detail(request, task_id):
    """
    GET /api/tasks/{id}/ - Get a specific task
    PUT/PATCH /api/tasks/{id}/ - Update a task
    DELETE /api/tasks/{id}/ - Delete a task
    """
    try:
        task = Task.objects.get(id=task_id)
    except Task.DoesNotExist:
        return JsonResponse({
            'status': 'error',
            'message': 'Task not found'
        }, status=404)
    
    if request.method == 'GET':
        return JsonResponse({
            'status': 'success',
            'data': {
                'id': task.id,
                'title': task.title,
                'description': task.description,
                'status': task.status,
                'priority': task.priority,
                'created': task.created,
                'updated_at': task.updated_at,
                'user_id': task.user_id,
                'username': task.user.username
            }
        })
    
    elif request.method in ['PUT', 'PATCH']:
        try:
            data = json.loads(request.body)
            
            # Update fields if provided
            if 'title' in data:
                task.title = data['title']
            if 'description' in data:
                task.description = data['description']
            if 'status' in data:
                task.status = data['status']
            if 'priority' in data:
                task.priority = data['priority']
            if 'user_id' in data:
                try:
                    user = User.objects.get(id=data['user_id'])
                    task.user = user
                except User.DoesNotExist:
                    return JsonResponse({
                        'status': 'error',
                        'message': 'User with this ID does not exist'
                    }, status=400)
            
            task.save()
            
            return JsonResponse({
                'status': 'success',
                'message': 'Task updated successfully',
                'data': {
                    'id': task.id,
                    'title': task.title,
                    'description': task.description,
                    'status': task.status,
                    'priority': task.priority,
                    'created': task.created,
                    'updated_at': task.updated_at,
                    'user_id': task.user_id,
                    'username': task.user.username
                }
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON data'
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    elif request.method == 'DELETE':
        task.delete()
        return JsonResponse({
            'status': 'success',
            'message': 'Task deleted successfully'
        })

@require_http_methods(["GET"])
def tasks_by_status(request):
    """GET /api/tasks/status/{status}/ - Filter tasks by status"""
    status_filter = request.GET.get('status', None)
    if status_filter:
        tasks = Task.objects.filter(status=status_filter).values(
            'id', 'title', 'description', 'status', 'priority', 
            'created', 'updated_at', 'user__username', 'user_id'
        )
    else:
        tasks = Task.objects.all().values(
            'id', 'title', 'description', 'status', 'priority', 
            'created', 'updated_at', 'user__username', 'user_id'
        )
    
    return JsonResponse({
        'status': 'success',
        'filter': status_filter,
        'count': len(tasks),
        'data': list(tasks)
    })

@require_http_methods(["GET"])
def tasks_by_priority(request):
    """GET /api/tasks/priority/ - Filter tasks by priority"""
    priority_filter = request.GET.get('priority', None)
    if priority_filter:
        tasks = Task.objects.filter(priority=priority_filter).values(
            'id', 'title', 'description', 'status', 'priority', 
            'created', 'updated_at', 'user__username', 'user_id'
        )
    else:
        tasks = Task.objects.all().values(
            'id', 'title', 'description', 'status', 'priority', 
            'created', 'updated_at', 'user__username', 'user_id'
        )
    
    return JsonResponse({
        'status': 'success',
        'filter': priority_filter,
        'count': len(tasks),
        'data': list(tasks)
    })

@require_http_methods(["GET"])
def user_list(request):
    """GET /api/users/ - List all users"""
    users = User.objects.all().values('id', 'username', 'email', 'first_name', 'last_name')
    return JsonResponse({
        'status': 'success',
        'count': len(users),
        'data': list(users)
    })
