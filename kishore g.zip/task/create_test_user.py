#!/usr/bin/env python
import os
import sys
import django

# Add the project directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'apitesting.settings')
django.setup()

from django.contrib.auth.models import User

# Create a test user if it doesn't exist
try:
    user = User.objects.get(username='testuser')
    print(f"User 'testuser' already exists with ID: {user.id}")
except User.DoesNotExist:
    user = User.objects.create_user(
        username='testuser',
        email='test@example.com',
        password='testpassword123',
        first_name='Test',
        last_name='User'
    )
    print(f"Created test user with ID: {user.id}")

# List all users
users = User.objects.all()
print(f"\nAll users in the system:")
for u in users:
    print(f"ID: {u.id}, Username: {u.username}, Email: {u.email}")