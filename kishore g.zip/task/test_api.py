#!/usr/bin/env python
import requests
import json

# API base URL
BASE_URL = "http://127.0.0.1:8000/api"

print("=== Django Task API Testing ===\n")

# Test 1: Get all users
print("1. Testing GET /api/users/")
try:
    response = requests.get(f"{BASE_URL}/users/")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*50 + "\n")

# Test 2: Create a new task
print("2. Testing POST /api/tasks/")
task_data = {
    "title": "Test Task from Script",
    "description": "This is a test task created via API script",
    "status": "pending",
    "priority": "inprocess",
    "user_id": 1
}

try:
    response = requests.post(
        f"{BASE_URL}/tasks/",
        headers={"Content-Type": "application/json"},
        data=json.dumps(task_data)
    )
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
    
    if response.status_code == 201:
        created_task = response.json().get('data', {})
        task_id = created_task.get('id')
        print(f"\n✅ Task created successfully with ID: {task_id}")
    else:
        print(f"\n❌ Failed to create task")
        
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*50 + "\n")

# Test 3: Get all tasks
print("3. Testing GET /api/tasks/")
try:
    response = requests.get(f"{BASE_URL}/tasks/")
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
except Exception as e:
    print(f"Error: {e}")

print("\n" + "="*50 + "\n")

# Test 4: Test with invalid data (missing required field)
print("4. Testing POST /api/tasks/ with invalid data")
invalid_data = {
    "title": "Incomplete Task",
    "user_id": 1
    # Missing description
}

try:
    response = requests.post(
        f"{BASE_URL}/tasks/",
        headers={"Content-Type": "application/json"},
        data=json.dumps(invalid_data)
    )
    print(f"Status Code: {response.status_code}")
    print(f"Response: {json.dumps(response.json(), indent=2)}")
except Exception as e:
    print(f"Error: {e}")

print("\n=== Testing Complete ===")